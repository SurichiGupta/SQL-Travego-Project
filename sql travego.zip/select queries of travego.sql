use travego;


select * from passenger;
select * from price;
# 1 .	How many females and how many male passengers traveled a minimum distance of 600 KMs?
-- Count of females who traveled a minimum of 600 KMs
SELECT gender ,count(*) as female_counts
FROM passenger
where distance>=600
group by gender;


select * from passenger;

-- 2.Find the minimum ticket price of a Sleeper Bus
SELECT MIN(Price) AS MinSleeperBusPrice
FROM price
WHERE Bus_Type = 'Sleeper';

#3.	Select passenger names whose names start with character 'S' 
select passenger_name from passenger 
where passenger_name like 'S%';

#4. Calculate price charged for each passenger displaying Passenger name, Boarding City, Destination City, Bus_Type, Price in the output
select p.Passenger_name, p.Boarding_City, p.Destination_City, p.bus_type,pr.price from passenger p left join price pr
on p.passenger_id= pr.id;

#5. What are the passenger name(s) and the ticket price for those who traveled 1000 KMs Sitting in a bus?  
select p.passenger_name,pr.price from passenger p inner join price pr
on p.passenger_id=pr.id
where p.distance = '1000' and  p.bus_type like 'Sitting';

#6.	What will be the Sitting and Sleeper bus charge for Pallavi to travel from panaji to bengaluru?
Select p.Passenger_name, p.Destination_City as Boarding_City, p.Boarding_City as Destination_City, pr.Bus_Type, pr.Price 
from passenger p join price pr on p.Distance = pr.Distance where p.Passenger_name like 'Pallavi';

#7 List the distances from the "Passenger" table which are unique (non-repeated distances) in descending order. 
select distinct distance from passenger
order by distance desc;

#8.	Display the passenger name and percentage of distance traveled by that passenger from the total distance traveled by all passengers 
select passenger_name,(distance*100/(select sum(distance) from passenger)) as distance_travelled from passenger;





